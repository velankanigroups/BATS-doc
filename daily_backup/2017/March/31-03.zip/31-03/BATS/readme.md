BATS - ByDesign automobile tracking system

Bats v1.0
      
       Bats version 1.0 contains live tracking screen where the particular device will be communicating to server and by api we'll get the update
       and it get plotted in the map with the info window show the detail of the location.
       
BATS v1.1

       This version includes three different users (factory,admin and general).
       
       
BATS v1.2 (release for Crowne Plaza)      

       This version includes three different users (factory,admin and general).
       a) released with new svg and improvised live tracking facility.
       b) imported all modules in app to web
       
       
BATS v1.3.1

       This version includes three different users (factory,admin and general).Also this version has the improvised ui and the flow of the application will be
       
       a) factory user assign devices to the admin user.
       b) admin user will create group with that device and get activate it to see that on live tracking screen.
       c) analytics is removed from this build for upgrades
       d) listing devices based on vehicle no or device id 
       e) 
       
       
       
                             
      