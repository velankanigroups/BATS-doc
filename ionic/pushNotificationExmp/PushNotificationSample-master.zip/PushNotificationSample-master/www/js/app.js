/**
 * Author: hollyschinsky
 * twitter: @devgirfl
 * blog: devgirl.org
 * more tutorials: hollyschinsky.github.io
 */
var app = angular.module('app', ['ionic','ngCordova'])
    .run(function($ionicPlatform) {
})


