package com.ionicframework.driverapp210332;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Log;

/**
 * Created by dell on 6/10/2016.
 */
public class MyReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        Log.i("MyReceiver", "!@#$%^&*(!@#$%^&*(!@#$%^&*())!@#$%^&*(!@#$%^&*(!@#$%^&*()");
        Intent service1 = new Intent(context, MyAlarmService.class);
        context.startService(service1);
    }
}
