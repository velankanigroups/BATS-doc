package com.ionicframework.driverapp210332;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.location.Address;
import android.location.Geocoder;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.IBinder;
import android.support.annotation.Nullable;
import android.text.format.DateFormat;
import android.util.Log;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.HttpStatus;
import org.apache.http.NameValuePair;
import org.apache.http.StatusLine;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.JSONTokener;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;

/**
 * Created by madhavan on 6/10/2016.
 * MyAlarmService has the following functionality
 * 1)fetching token by using Fetchtoke class
 * 2)fetching device/list api
 * 3)fetching device/currentdata api
 * 4)showing notification based on the currentdata results
 *
 * Notification Category *
 * 1) TYPE "0" for device crossed GEO FENCE
 * 2) TYPE "1" for device crossed SPEED LIMIT
 * 3) TYPE "2" for device crossed both ABOVE
 * 4) TYPE "4" for No Response State
 */
public class MyAlarmService extends Service {
    private NotificationManager mManager;
    Notification myNotification;
    public String apiURL = "http://220.227.124.134:8058/";
    public String tokenValue;
    public List<String> deviceArray =new ArrayList<String>();

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
    @Override
    public void onCreate() {
        super.onCreate();
    }

    @Override
    public void onStart(Intent intent, int startId) {
        super.onStart(intent, startId);
        SQLiteDatabase.CursorFactory factory = null;
        FetchToken tokenObj=new FetchToken(this,"my",factory,1);
        try {
        tokenValue=tokenObj.tokenValue();

        if(tokenObj.tokenValue()!=null){
            Log.i("TOKEN VALUE","============================="+tokenObj.tokenValue()+"============================");
            Log.i("MyAlarmService", "!@#$%^&*(!@#$%^&*(!@#$%^&*())!@#$%^&*(!@#$%^&*(!@#$%^&*()");
            String deviceAlarm="driver/app/pushalarmnotifications";
            Log.i("Start API Call", "<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<");
            new RestOperation().execute(deviceAlarm);
        }
        else{
            Log.i("TOKEN NOT UPDATED","=============================================TOKEN NOT AVAILABLE=====================================");
        }
        } catch (SQLException e) {
            e.printStackTrace();
        }

    }
    class RestOperation extends AsyncTask<String, Integer, String> {

        @Override
        protected String doInBackground(String... params) {

            if(params[0]=="driver/app/pushalarmnotifications"){
                fetchAlarmData(apiURL + params[0]);
            }
            return "string";
        }

        @Override
        protected void onPostExecute(String result) {
            super.onPostExecute(result);
            Log.i("RESULT", result);
                  }
        private void fetchAlarmData(String url){
            Log.i("we came","for alarm");
            List<String> panicArray=new ArrayList<String>();
            List<String> batteryArray=new ArrayList<String>();
            List<String> overspeedArray=new ArrayList<String>();
            List<String> geofenceArray=new ArrayList<String>();
            List<String> catArray=new ArrayList<String>();
            InputStream is = null;
            BufferedReader bufferedReader=null;
            String s = "";
            try {
                //created HttpClient
                HttpClient httpclient = new DefaultHttpClient();

                //made POST request to the given URL
                HttpPost httpPost = new HttpPost(url);

                List<NameValuePair> list = new ArrayList<NameValuePair>();
                list.add(new BasicNameValuePair("token", tokenValue));

                httpPost.setEntity(new UrlEncodedFormEntity(list));
                HttpResponse httpResponse = httpclient.execute(httpPost);

                HttpEntity httpEntity = httpResponse.getEntity();
                is = httpResponse.getEntity().getContent();
                bufferedReader = new BufferedReader(new InputStreamReader(is));
                String line = "";
                StringBuffer sb = new StringBuffer();
                while ((line = bufferedReader.readLine()) != null) {
                    sb.append(line);
                }
                String notificationData = sb.toString();

                JSONObject notificationObject= new JSONObject(notificationData);
                JSONArray alarmArray=notificationObject.getJSONArray("alarm_data");
                JSONArray tripArray=notificationObject.getJSONArray("trips");
                int trip_len=tripArray.length();
                for(int i=0;i<trip_len;i++){
                    JSONObject tripObject = tripArray.getJSONObject(i);
                    showNotification(tripObject,"TRIP");
                }
                int alarm_len = alarmArray.length();
                for (int inc = 0; inc < alarm_len; inc++) {
                    JSONObject alarmObject = alarmArray.getJSONObject(inc);
                    //Panic Alarm
                    if (alarmObject.optString("alarm_type").toString().equals("PAT")) {
                        showNotification(alarmObject,"PAT");
                    }
                    //Battery  Alarm
                    else if (alarmObject.optString("alarm_type").toString().equals("BAT")) {
                        showNotification(alarmObject,"BAT");
                    }
                    //OverSpeed Alarm
                    else if (alarmObject.optString("alarm_type").toString().equals("overspeed")) {
                        showNotification(alarmObject,"overspeed");
                    }
                    //Geo fence crossed alarm
                    else if (alarmObject.optString("alarm_type").toString().equals("geofence")) {
                        showNotification(alarmObject,"geofence");
                    }
                    //Cable Alarm
                    else if (alarmObject.optString("alarm_type").toString().equals("CAT")) {
                        showNotification(alarmObject,"CAT");
                    }
                }

            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            } catch (JSONException e) {
                e.printStackTrace();
            }
            finally {
                close(bufferedReader);
            }
        }


        private void close(BufferedReader reader) {
            if (reader != null) {
                try {
                    reader.close();
                } catch (IOException exp) {
                    Log.e("TAG", "", exp);
                }
            }
            }
    }
    private void showNotification(JSONObject data, String s) {
        Log.i("AT NOTIFICATION",data.toString());
        Geocoder geocoder = new Geocoder(this, Locale.getDefault());
        String notificationString="";
        String notificationTitle="";
        if(s.equals("PAT")){
            //List<Address> addresses= geocoder.getFromLocation(Integer.parseInt(data.optString("lat").toString()),Integer.parseInt(data.optString("long").toString()), 1);
            notificationTitle="PANIC ALARM";
            notificationString="Vehicle Number"+data.optString("vehicle_num").toString();//+"Address:"+addresses;
        }
        else if(s.equals("BAT")){
            // List<Address> addresses= geocoder.getFromLocation(Integer.parseInt(data.optString("lat").toString()),Integer.parseInt(data.optString("long").toString()), 1);
            notificationTitle="BATTERY ALARM";
            notificationString="Vehicle Number"+data.optString("vehicle_num").toString();//+"Address:"+addresses;
        }
        else if(s.equals("overspeed")){
            //List<Address> addresses= geocoder.getFromLocation(Integer.parseInt(data.optString("lat").toString()),Integer.parseInt(data.optString("long").toString()), 1);
            notificationTitle="OVERSPEED ALARM";
            notificationString="Vehicle Number"+data.optString("vehicle_num").toString();//+"Address:"+addresses;
        }
        else if(s.equals("geofence")){
            try {
                List<Address> addresses= geocoder.getFromLocation(Integer.parseInt(data.optString("lat").toString()),Integer.parseInt(data.optString("long").toString()), 1);
                notificationTitle="GEOFENCE ALARM";
                notificationString="Vehicle Number"+data.optString("vehicle_num").toString()+"Address:"+addresses;
                } catch (IOException e) {
                    e.printStackTrace();
                }
        }
        else if(s.equals("overspeed")){
            //List<Address> addresses= geocoder.getFromLocation(Integer.parseInt(data.optString("lat").toString()),Integer.parseInt(data.optString("long").toString()), 1);
            notificationTitle="POWER INTERRUPT ALARM";
            notificationString="Vehicle Number"+data.optString("vehicle_num").toString();//+"Address:"+addresses;
        }
        else if(s.equals("TRIP")){
            try {
                notificationTitle="TRIP NOTIFICATION";
                JSONObject startPointObject= data.getJSONObject("td_start_point");
                JSONObject endPointObject= data.getJSONObject("td_end_point");
                notificationString="Trip Time"+getDate(Long.parseLong(startPointObject.optString("ts").toString()))+"Location:"+endPointObject.optString("name");
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }

        mManager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        Intent intent1 = new Intent(this.getApplicationContext(),MainActivity.class);
        PendingIntent pendingNotificationIntent = PendingIntent.getActivity( this.getApplicationContext(),0, intent1,PendingIntent.FLAG_UPDATE_CURRENT);
        Notification.Builder builder = new Notification.Builder(this);
        builder.setAutoCancel(false);
        builder.setTicker("ByDesign Tracker Alarm");
        builder.setContentTitle(notificationTitle);
        builder.setContentText(notificationString);
        builder.setSmallIcon(R.drawable.icon);
        builder.setContentIntent(pendingNotificationIntent);
        builder.setOngoing(true);
        builder.setAutoCancel(true);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN) {
            builder.build();
        }
        Uri alarmSound = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
        builder.setSound(alarmSound);
        myNotification = builder.getNotification();
        myNotification.flags=  Notification.FLAG_ONLY_ALERT_ONCE | Notification.FLAG_AUTO_CANCEL ;

        mManager.notify(getRandomNumberInRange(1,1000), myNotification);

    }
    private static int getRandomNumberInRange(int min, int max) {

        if (min >= max) {
            throw new IllegalArgumentException("max must be greater than min");
        }

        return (int)(Math.random() * ((max - min) + 1)) + min;
    }

    private String getDate(long time) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTimeInMillis(time);

        int mYear = calendar.get(Calendar.YEAR);
        int mDate=calendar.get(Calendar.DATE);
        int mHour=calendar.get(Calendar.HOUR_OF_DAY);
        int mMinute=calendar.get(Calendar.MINUTE);
        String AM_PM="";
        if(calendar.get(Calendar.AM_PM) == Calendar.AM){
            AM_PM="AM";
        }
        if(calendar.get(Calendar.AM_PM) == Calendar.PM){
            AM_PM="PM";
        }
        return "Date: "+mDate+"/"+theMonth(calendar.get(Calendar.MONTH))+"/"+mYear+" TIME: "+mHour+":"+mMinute+" "+AM_PM;
    }
    public static String theMonth(int month){
        //String[] monthNames = {"Jan", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"};
        String[] monthNames = {"01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12"};
        return monthNames[month];
    }
}
