package com.ionicframework.driverapp210332;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import java.io.File;
import java.sql.SQLException;

/**
 * Created by madhavan on 8/22/2016.
 */
public class InsertIMEI extends SQLiteOpenHelper {
    private static final String IMEI_COLUMN_NAME = "imei";
    private static String DB_PATH = "";
    private static String DB_NAME = "my.db";
    private SQLiteDatabase myDataBase;
    public String imeivalue;
    public InsertIMEI(Context context, String name, SQLiteDatabase.CursorFactory factory, int version) {
        super(context, name, factory, version);
        if(android.os.Build.VERSION.SDK_INT >= 17){
            Log.i(">>>>>>>=17",String.valueOf(android.os.Build.VERSION.SDK_INT));
            DB_PATH = context.getApplicationInfo().dataDir + "/databases/";
        }
        else
        {
            DB_PATH = "/data/data/" + context.getPackageName() + "/databases/";
        }
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }
    /**
     *                   Function to Insert IMEI no into db
     * */
    public void insertIMEI(String IMEI) throws SQLException{
        Log.i("INSERT",IMEI+"======================================================");
        openDataBase();
        boolean dbExist = checkDataBase();

        if(dbExist){
            Log.i("DB EXIST", "=====================================DB IMEI EXIST=========================");
            openDataBase();

            //myDataBase.execSQL("CREATE TABLE IF NOT EXISTS Device_IMEI(imei VARCHAR);");
            String query = "INSERT INTO Device_IMEI (imei) VALUES('"+IMEI+"');";
            myDataBase.execSQL(query);

        } else {
            Log.i("DB NOT CREATED", "=========================================DB IMEI NOT CREATED===========================");
        }

    }
    public String checkIMEI() throws SQLException {
        boolean dbExist = checkDataBase();
        Log.i("dbExist",String.valueOf(dbExist));
        if(dbExist){
            Log.i("DB EXIST","=====================================DB EXIST=========================");
            openDataBase();

            Cursor res =  myDataBase.rawQuery( "select * from Device_IMEI", null );
            res.moveToFirst();

            while(res.isAfterLast() == false){
                imeivalue = res.getString(res.getColumnIndex(IMEI_COLUMN_NAME));
                res.moveToNext();
            }

        }
        else{
            Log.i("DB NOT CREATED","=========================================DB NOT CREATED===========================");
        }
        return imeivalue;
    }
    /**
     * Check if the database already exist to avoid re-copying the file each time you open the application.
     * @return true if it exists, false if it doesn't
     */
    private boolean checkDataBase(){

        File dbFile = new File(DB_PATH + DB_NAME);
        //Log.v("dbFile", dbFile + "   "+ dbFile.exists());
        return dbFile.exists();
    }
    public void openDataBase() throws SQLException {
        Log.i("opening DB","DB");
        //Open the database
        String myPath = DB_PATH + DB_NAME;
        Log.i("DB_PATH",">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>"+myPath+"<<<<<<<<<<<<<<<<<<<<<<<<<<<<");
        myDataBase = SQLiteDatabase.openDatabase(myPath, null, SQLiteDatabase.OPEN_READWRITE);

    }
}
