driverApp.controller('eventNotificationsCtrl', function($scope, $state,driverAppFactory,driverAppService) {
	
});